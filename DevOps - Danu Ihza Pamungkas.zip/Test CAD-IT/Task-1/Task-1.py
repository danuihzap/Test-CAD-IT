try:
    N = int(input("Digit: "))
    digit=0
    suffix='th'
    for i in range(1,N+1):
        digit+=len(str(i))
        if(digit>=N):
            if(N==1):
                suffix="st"
            if(N==2):
                suffix="nd"
            if(N==3):
                suffix="rd"
            print(str(N)+suffix, "digit number is", str(i)[len(str(N))-1-(digit-N)], "lies on number", i)
            break
except:
    print("Input is not correct")